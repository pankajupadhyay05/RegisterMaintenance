﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace RegisterMaintenance
{
    /// <summary>
    /// Interaction logic for PrintEditInvoice.xaml
    /// </summary>
    public partial class PrintInvoice : Page
    {
        public PrintInvoice()
        {
            InitializeComponent();
        }
    }
}
