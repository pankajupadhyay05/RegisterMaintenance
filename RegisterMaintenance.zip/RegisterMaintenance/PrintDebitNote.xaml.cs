﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace RegisterMaintenance
{
    /// <summary>
    /// Interaction logic for PrintDebitNote.xaml
    /// </summary>
    public partial class PrintDebitNote : Page
    {
        public PrintDebitNote()
        {
            InitializeComponent();
        }
        public void cleanDebitNote()
        {
            
        }
    }
}
